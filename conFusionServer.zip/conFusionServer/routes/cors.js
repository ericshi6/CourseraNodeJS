const express = require('express');
const cors = require('cors');
const app = express();

var whitelist = ['http://localhost:3000', 'https://localhost:3443', 'http://localhost:4200'];
var corsOptionsDelegate = (req, callback) => {
    var corsOptions;
    console.log(req.header('Origin'));

    //return index of object in array
    if(whitelist.indexOf(req.header('Origin')) !== -1) {
        corsOptions = { origin: true };
    }
    else {
    	//if not in whitelist
        corsOptions = { origin: false };
    }
    callback(null, corsOptions);
};

exports.cors = cors(); //will respond with wildcard *
exports.corsWithOptions = cors(corsOptionsDelegate);