module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/conFusion',
    'facebook': {
    	'clientId': '723912201469990',
        'clientSecret': '73dca6211b96c28b78d482e3f790b17a'
   	}
}